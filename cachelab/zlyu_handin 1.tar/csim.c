/*
 * Zekun Lyu
 * zlyu
 * csim.c - simulation of a cache
 *
 * the function will read in E, s, b as argument from command line,
 * and read instructions from a trace file, based on the command simulate
 * accessing to cache and calculate total number of hit, miss and eviction
 *
 */

#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
//#include <string.h>

#define INFINITE 0x7FFFFFFF

typedef struct {
    int lastTime; /* the number of trace line last time used*/
    int valid; /* valid flag*/
    unsigned long long int tag; /* tag of the line*/
} Line;

typedef struct{
    Line* lines;
    int setIndex;
} Set;

typedef struct{
    Set* sets;
    int E;
    int s;
    int b;
    int hCount;
    int mCount;
    int eCount;
    int timer;
    
}Cache;

/* create an initial cache*/
Cache createCache(int s, int E, int b)
{
    Cache c;
    int S=1<<s;
    c.sets = (Set *)malloc(S*sizeof(Set));
    c.s=s;
    c.b=b;
    c.E=E;
    
    c.eCount=0;
    c.hCount=0;
    c.mCount=0;
    c.timer=0;
    
    for (int i=0; i<S; i++)
    {
        //Set * curS = c.sets+i;
        c.sets[i].lines = (Line *)malloc(E*sizeof(Line));
        for (int j=0; j<E; j++)
        {
            Line * line = c.sets->lines+j;
            line->valid = 0;
            line->tag = 0;
            line->lastTime = 0;
        }
    }
    
    return c;
}


/* simulate a single access to the cache*/
void accessAddress(Cache * c, unsigned long long int addr)
{
    c->timer++;
    /* set selection*/
    // calculate set index
    int b=c->b;
    int mask=(1<<c->s)-1;
    unsigned long long int setIndex=(addr>>b)&mask;
    Set set = c->sets[setIndex];
    
    /* line matching*/
    // calculate tag
    unsigned long long int tag=addr>>(c->s+c->b);
    Line *hitLine=NULL;
    int isFullSet=1;
    for (int i=0; i<c->E; i++)
    {
        Line *line = set.lines+i;
        if((line->tag==tag)&&(line->valid==1))
        {
            hitLine = line;
        }
        else if(line->valid==0)
        {
            isFullSet=0;
        }
    }
    if (hitLine!=NULL)
    {
        hitLine->lastTime=c->timer;
        c->hCount++;
    }
    else /* perform a miss*/
    {
        c->mCount++;
        if(isFullSet==0)
        {
            for(int i=0; i<c->E; i++)
            {
                Line * line = set.lines+i;
                if(!line->valid)
                {
                    line->valid=1;
                    line->tag=tag;
                    line->lastTime=c->timer;
                    break;
                }
            }
        }
        else /* perform an eviction*/
        {
            c->eCount++;
            int latest=INFINITE;
            Line * evictedLine=NULL;
            for(int i=0; i<c->E; i++)
            {
                Line * line=set.lines+i;
                if(line->lastTime<latest)
                {
                    latest=line->lastTime;
                    evictedLine=line;
                }
            }
            evictedLine->valid=1;
            evictedLine->tag=tag;
            evictedLine->lastTime=c->timer;
            
        }
    }
    
}

/* free the location malloced for cache*/
void clearCache(Cache * c)
{
    for(int i=0; i<(1<<c->s); i++)
    {
        Set *set = c->sets+i;
        if (set->lines!=NULL)
            free(set->lines);
    }
    free(c->sets);
}

int main(int argc, char *argv[])
{
    int E=0, s=0, b=0;
    char* tFile=NULL;
    char* optStr="E:s:b:t:";
    int ch;
    
    // get argument from command line
    while ((ch = getopt(argc,argv,optStr))!=-1)
    {
        switch (ch) {
            case 'E':
                E = atoi(optarg);
                break;
                
            case 's':
                s = atoi(optarg);
                break;
            case 'b':
                b = atoi(optarg);
                break;
            case 't':
                tFile=optarg;
                break;
            default:
                break;
        }
    }
    
    Cache cache = createCache(s, E, b);
    FILE * trace=fopen(tFile, "r");
    if (trace!=NULL)
    {
        char symbol;
        unsigned long long int addr;
        int size;
        int lineNum=0;
        
        //read the trace file
        while(!feof(trace))
        {
            lineNum++;
            int readNum = fscanf(trace," %c %llx,%d",&symbol,&addr,&size);
            if (readNum==3)
            {
                switch(symbol)
                {
                    case 'I':
                        break;
                    case 'L':
                        accessAddress(&cache,addr);
                        break;
                    case 'S':
                        accessAddress(&cache,addr);
                        break;
                    case 'M':
                        accessAddress(&cache,addr);
                        accessAddress(&cache,addr);
                        break;
                    default:
                        break;
                }
            }
        }
    }
    printSummary(cache.hCount,cache.mCount,cache.eCount);
    clearCache(&cache);
    fclose(trace);
    return 0;
}